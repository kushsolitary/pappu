  var canvas = CocoonJS.App.createScreenCanvas();
  var ctx = canvas.getContext('2d');

  W = canvas.width = 1136;
  H = canvas.height = 640;
